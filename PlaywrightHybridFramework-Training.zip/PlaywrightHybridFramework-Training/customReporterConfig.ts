import { Reporter, TestCase, TestError, TestResult, TestStep } from "@playwright/test/reporter";
import winston from 'winston';
import axios from "axios"

const customFormat = winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.printf(({ level, message, timestamp }) => `[${timestamp}] ${level.toUpperCase()}: ${message}`)
);

const logger = winston.createLogger({
    level: 'info',
    format: customFormat,
    transports: [
        new winston.transports.Console({ level: 'debug' }),
        new winston.transports.File({ filename: 'logs/info.log', level: 'info' }),
        new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
        new winston.transports.File({ filename: 'logs/debug.log', level: 'debug' }),
    ],
});

class CustomReporter implements Reporter {

    private executionId: string = '';
    private token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInVzZXJuYW1lIjoiYWRtaW5AZXhhbXBsZS5jb20iLCJyb2xlIjoiYWRtaW4iLCJpYXQiOjE3Nzc3OTA3NTAsImV4cCI6MTc3Nzg3NzE1MH0.bQokKQeiCCp19lSttBEr9PJZnqZnd29c083WWwuo37s';

    private api = axios.create({
        baseURL: 'http://localhost:3001/api',
        headers: {
            Authorization: `Bearer ${this.token}`,
            'Content-Type': 'application/json'
        }
    });

    async onBegin(config: any, suite: any) {
    const response = await this.api.post('/tests/start', {
        testSuite: 'Playwright Suite',
        environment: 'local',
        framework: 'Playwright',
        project: {
            id: 1,
            name: 'My Project',
            type: 'web'
        }
    });

    this.executionId = response.data.reportId;

    logger.info(`Execution started: ${this.executionId}`);
}
    
async onTestEnd(test: TestCase, result: TestResult) {
    await this.api.post('/tests/result', {
        executionId: this.executionId,
        testName: test.title,
        status: result.status,
        duration: result.duration,
        error: result.error?.message || null
    });
}

async onStep(test: TestCase, result: TestResult, step: TestStep) {
    await this.api.post('/tests/step', {
        reportId: this.executionId,
        testName: test.title,
        stepName: step.title,
        status: step.error ? 'failed' : 'passed',
        duration: step.duration || 0
    });
}

    async onEnd(result: any) {
    await this.api.post('/tests/complete', {
        reportId: this.executionId,
        summary: {
            total: result.total,
            passed: result.passed,
            failed: result.failed,
            skipped: result.skipped,
            duration: result.duration,
            passRate: 80
        }
    });
    }
}

export default CustomReporter;
