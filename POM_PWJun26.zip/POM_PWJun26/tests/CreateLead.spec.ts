
import dotenv from "dotenv"
import {LoginPage  } from "../pages/01-loginPage";
import { test } from "@playwright/test";
import credentials from "../Data/login.json"
import { WelcomePage } from "../pages/02-welcomePage";
import { HomePage } from "../pages/03-homePage";
import { LeadPage } from "../pages/04-leadPage";
import { CreateLeadPage } from "../pages/05-createLeadPage";
import { ViewLeadPage } from "../pages/06-viewLeadPage";

dotenv.config({path:"Data/prod.env"})


test("Login page functionality check using POM",async ({page}) => {

    const obj = new LoginPage(page) // created an object to invoke th special method called constructor and apss the arguments

    await obj.loadUrl(process.env.BaseUrl as string)
    await obj.enterCrdentials(credentials[0].username,credentials[0].password);
    await obj.clickLogin();
  
    const wp = new WelcomePage(page)
    await wp.clickCRM()

    const hp = new HomePage(page)
    await hp.clickLeads()

    const lp = new LeadPage(page)
    await lp.clickCreateLead()

    const clp = new CreateLeadPage(page)
    await clp.enterMandatoryFields()
    await clp.clickSubmit()

    const vp = new ViewLeadPage(page)
    await vp.verifyFirstName()
    


    await page.waitForTimeout(3000)






})


/* LoginPage -> WelcomePage -> HonePage -> LeadPage -> CreateLeadPage->ViewLead */

