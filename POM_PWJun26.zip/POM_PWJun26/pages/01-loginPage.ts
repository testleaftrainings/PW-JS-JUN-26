

/* Actionables : ==> methods
1. Loading url
2. Enter Credential
3. Click Login */

import { Page } from "@playwright/test";
import { PWWrapper } from "../utility/playwrightWrapper";
import { locators } from "./locators";

export class LoginPage extends PWWrapper {

    // page : Page // it is a property of the LoginPage class 

    // constructor(Lpage:Page){ // here Page is the type of the local variable Lpage

    //     this.page = Lpage // Gets Initilized first
    // }

    async loadUrl(url: string) {
        console.log("This load url method");
        await this.page.goto(url);
        console.log(await this.getTitle())
    }



    async enterCrdentials(usr: string, pwd: string) {
        // await this.page.locator("#username").fill(usr);
        // await this.page.locator("#password").fill(pwd);

        // await this.clearAndFill(this.loginPageLocator.userfield, usr); //locators within the page
        // await this.page.locator(this.loginPageLocator.passwordfield).fill(pwd);

        await this.clearAndFill(locators.userfield, usr); // locators outside the class 
        await this.page.locator(locators.passwordfield).fill(pwd); 
    }


    async clickLogin() {
        await this.page.locator(".decorativeSubmit").click()
    }

    // loginPageLocator= { // storing locators as objects in the respective class

    //     userfield : "#username",
    //     passwordfield : "#password"

    // }


}

