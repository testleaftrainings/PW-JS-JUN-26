import { LoginPage } from "./01-loginPage";
import { PWWrapper } from "./plyawrightWrapper";


export class HomePage extends PWWrapper {

    async clickLeads() {
        await this.page.locator('//a[text()="Leads"]').click();
        console.log(await this.getTitle())
    }

    async clickAccounts() {

        await this.page.locator('//a[text()="Accounts"]').click();

    }

}