import { expect } from "@playwright/test";
import { PWWrapper } from "../utility/playwrightWrapper";


export class ViewLeadPage extends PWWrapper{

async verifyFirstName(){
    
    const fName = await this.page.locator('//span[@id="viewLead_firstName_sp"]').innerText();
    console.log(fName);
   // expect(fName).toBe("Ravindran")
    
}

}