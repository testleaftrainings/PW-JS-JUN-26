

export const locators = {

    "userfield": "#username",
    "passwordfield": "#password"
}