import { LoginPage } from "./01-loginPage";
import { PWWrapper } from "../utility/playwrightWrapper";


export class WelcomePage extends PWWrapper { // We are exteding to get the page reference which is a property of parent class "LoginPage"

    async clickCRM() {

        await this.page.locator(this.welcomePageLocator.crmClick).click()
        console.log(await this.getTitle())

    }

    welcomePageLocator = { // storing locators as objects in the respective class
        crmClick : '//a[contains(text(),"CRM")]'
    }
}