import { PWWrapper } from "./plyawrightWrapper";


export class LeadPage extends PWWrapper {

    async clickCreateLead() {

        await this.page.locator('//a[text()="Create Lead"]').click()

    }

}