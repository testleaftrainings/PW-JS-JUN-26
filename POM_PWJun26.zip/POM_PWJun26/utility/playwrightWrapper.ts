import { Page } from "@playwright/test";


export class PWWrapper{


page : Page // it is a property of the LoginPage class 

constructor(Lpage:Page){ // here Page is the type of the local variable Lpage

    this.page = Lpage // Gets Initilized first
}


async getTitle():Promise<string>{

    const title = await this.page.title()
    return title

}

async clearAndFill(locat:string,data:string){

await this.page.locator(locat).clear()
await this.page.locator(locat).fill(data)

}


}