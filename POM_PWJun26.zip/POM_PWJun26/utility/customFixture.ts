
import { test as baseTest} from "@playwright/test";
import { LoginPage } from "../pages/01-loginPage";
import { WelcomePage } from "../pages/02-welcomePage";
import { HomePage } from "../pages/03-homePage";
import { LeadPage } from "../pages/04-leadPage";
import { CreateLeadPage } from "../pages/05-createLeadPage";
import { ViewLeadPage } from "../pages/06-viewLeadPage";


type myFixtures = {

    loginfix: LoginPage,
    wpfix:WelcomePage,
    hpfix: HomePage,
    lpfix:LeadPage,
    clpfix:CreateLeadPage,
    vpfix:ViewLeadPage
    
     

    //page : Page (interface)
    //request : APIRequestContext(interface)

}



// export const customtest = test.extend<myFixtures>({
export const test = baseTest.extend<myFixtures>({

    //customized fixture 
    //Here loginfix is readily available fixture for login page object

    loginfix: async ({ page }, use) => {  // key : value
        const lop = new LoginPage(page)
        await use(lop)
    },
    wpfix: async ({ page }, use) => {  // key : value
        const wp = new WelcomePage(page)
        await use(wp)
    },

    hpfix: async ({page }, use) => {  // key : value

        const hp = new HomePage(page)
        await use(hp)
    },

    lpfix: async ({ page }, use) => {  // key : value

        const lp = new LeadPage(page)
        await use(lp)
    },

    clpfix: async ({ page }, use) => {  // key : value

        const clp = new CreateLeadPage(page)
        await use(clp)
    },

    vpfix: async ({ page }, use) => {  // key : value

        const vp = new ViewLeadPage(page)
        await use(vp)
    },








})   // (features of "test" as well as extend feature loginfix(object))





/* Normal predefined test has "test" keyword ==> page fixture => pre-requisite to laucn and create a context and page
                 "customtest"  ==> custom fixture => "page" fixture + "loginfix" object of login page */