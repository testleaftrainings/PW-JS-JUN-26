# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: CreateLead.spec.ts >> Login page functionality check using POM
- Location: CreateLead.spec.ts:15:5

# Error details

```
Error: page.goto: url: expected string, got undefined
```

# Test source

```ts
  1  | 
  2  | 
  3  | /* Actionables : ==> methods
  4  | 1. Loading url
  5  | 2. Enter Credential
  6  | 3. Click Login */
  7  | 
  8  | import { Page } from "@playwright/test";
  9  | import { PWWrapper } from "./plyawrightWrapper";
  10 | import { locators } from "./locators";
  11 | 
  12 | export class LoginPage extends PWWrapper {
  13 | 
  14 |     // page : Page // it is a property of the LoginPage class 
  15 | 
  16 |     // constructor(Lpage:Page){ // here Page is the type of the local variable Lpage
  17 | 
  18 |     //     this.page = Lpage // Gets Initilized first
  19 |     // }
  20 | 
  21 |     async loadUrl(url: string) {
  22 |         console.log("This load url method");
> 23 |         await this.page.goto(url);
     |                         ^ Error: page.goto: url: expected string, got undefined
  24 |         console.log(await this.getTitle())
  25 |     }
  26 | 
  27 | 
  28 | 
  29 |     async enterCrdentials(usr: string, pwd: string) {
  30 |         // await this.page.locator("#username").fill(usr);
  31 |         // await this.page.locator("#password").fill(pwd);
  32 | 
  33 |         // await this.clearAndFill(this.loginPageLocator.userfield, usr); //locators within the page
  34 |         // await this.page.locator(this.loginPageLocator.passwordfield).fill(pwd);
  35 | 
  36 |         await this.clearAndFill(locators.userfield, usr); // locators outside the class 
  37 |         await this.page.locator(locators.passwordfield).fill(pwd); 
  38 |     }
  39 | 
  40 | 
  41 |     async clickLogin() {
  42 |         await this.page.locator(".decorativeSubmit").click()
  43 |     }
  44 | 
  45 |     // loginPageLocator= { // storing locators as objects in the respective class
  46 | 
  47 |     //     userfield : "#username",
  48 |     //     passwordfield : "#password"
  49 | 
  50 |     // }
  51 | 
  52 | 
  53 | }
  54 | 
  55 | 
```